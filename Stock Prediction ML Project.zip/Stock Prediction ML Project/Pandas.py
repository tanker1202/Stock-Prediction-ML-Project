import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn import neighbors
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsRegressor

df = pd.read_csv("Stock Data.csv")

df['Open - Close'] = df['Open'] - df['Close']
df['High - Low'] = df["High"] - df["Low"]
df = df.dropna()
X = df[["Open - Close", "High - Low"]]
Y = df["Close"]
x_train_reg, x_test_reg, y_train_reg, y_test_reg = train_test_split(X, Y, test_size = 0.25)
params = {'n_neighbors': [2,3,4,5,6,7,8,9,10,11,12,13,14,15]}
knn_reg = neighbors.KNeighborsRegressor()
model_reg = GridSearchCV(knn_reg, params, cv = 5)

model_reg.fit(x_train_reg, y_train_reg)
predictions = model_reg.predict(x_test_reg)
print(predictions)

rms = np.sqrt(np.mean(np.power((np.array(y_test_reg)-np.array(predictions)),2)))
print(rms)

data = pd.DataFrame({"Actual Close" : y_test_reg, "Predicted Close Value" : predictions})
print(data)